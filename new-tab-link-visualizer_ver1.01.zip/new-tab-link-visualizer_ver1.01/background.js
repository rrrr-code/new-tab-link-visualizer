const recentClicks = new Map();
const recentTabs = [];

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message?.type === "NTLV_CLICKED") {
    const tabId = sender.tab?.id;
    if (typeof tabId === "number") {
      recentClicks.set(tabId, {
        timestamp: Date.now(),
        fingerprint: message.fingerprint,
        pageUrl: message.pageUrl,
        modifiers: message.modifiers || {}
      });
    }
    sendResponse({ ok: true });
    return true;
  }

  if (message?.type === "NTLV_CHECK_RESULT") {
    const tabId = sender.tab?.id;
    const clickInfo = typeof tabId === "number" ? recentClicks.get(tabId) : null;

    if (!clickInfo) {
      sendResponse({ openedNewTab: false });
      return true;
    }

    const now = Date.now();
    const openedNewTab = recentTabs.some((item) => {
      return item.sourceTabId === tabId && now - item.timestamp <= 1500;
    });

    sendResponse({
      openedNewTab,
      fingerprint: clickInfo.fingerprint,
      pageUrl: clickInfo.pageUrl,
      modifiers: clickInfo.modifiers
    });
    return true;
  }
});

chrome.tabs.onCreated.addListener((tab) => {
  recentTabs.push({
    tabId: tab.id,
    openerTabId: tab.openerTabId,
    sourceTabId: tab.openerTabId,
    timestamp: Date.now()
  });

  pruneOldTabs();
});

function pruneOldTabs() {
  const now = Date.now();
  for (let i = recentTabs.length - 1; i >= 0; i--) {
    if (now - recentTabs[i].timestamp > 5000) {
      recentTabs.splice(i, 1);
    }
  }
}