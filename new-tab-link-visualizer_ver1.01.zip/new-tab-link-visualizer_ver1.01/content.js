const STORAGE_KEY = "ntlv_learning_v1";
const RULE_CLASS = "ntlv-rule-outline";
const LEARNED_CLASS = "ntlv-learned-outline";
const FINGERPRINT_ATTR = "data-ntlv-fingerprint";

init().catch(console.error);

async function init() {
  await scanAndApply();
  installClickTracker();
  observeDom();
}

function observeDom() {
  const observer = new MutationObserver(() => {
    scanAndApply().catch(console.error);
  });

  observer.observe(document.documentElement, {
    childList: true,
    subtree: true,
    attributes: true,
    attributeFilter: ["href", "target", "onclick", "class", "role"]
  });
}

async function scanAndApply() {
  const learning = await loadLearning();
  const elements = document.querySelectorAll("a, button, [role='link'], [onclick], div, span");

  for (const el of elements) {
    if (!(el instanceof HTMLElement)) continue;

    const fingerprint = makeFingerprint(el);
    el.setAttribute(FINGERPRINT_ATTR, fingerprint);

    const ruleMatch = isRuleBasedNewTab(el);
    const learnedMatch = !ruleMatch && shouldMarkByLearning(fingerprint, learning);

    el.classList.remove(RULE_CLASS, LEARNED_CLASS);

    if (ruleMatch) {
      el.classList.add(RULE_CLASS);
    } else if (learnedMatch) {
      el.classList.add(LEARNED_CLASS);
    }
  }
}

function isRuleBasedNewTab(el) {
  const target = (el.getAttribute("target") || "").toLowerCase();
  if (target === "_blank") return true;
  if (target && !["_self", "_parent", "_top"].includes(target)) return true;

  const onclick = [
    el.getAttribute("onclick") || "",
    el.getAttribute("onmousedown") || "",
    el.getAttribute("onmouseup") || ""
  ].join(" ").toLowerCase();

  if (onclick.includes("window.open")) return true;

  if (el instanceof HTMLAnchorElement) {
    const href = (el.getAttribute("href") || "").toLowerCase();
    if (href.startsWith("javascript:") && href.includes("window.open")) return true;
  }

  return false;
}

function shouldMarkByLearning(fingerprint, learning) {
  const entry = learning[fingerprint];
  if (!entry) return false;
  return (entry.score || 0) >= 4;
}

function installClickTracker() {
  document.addEventListener("click", (event) => {
    const target = event.target;
    if (!(target instanceof Element)) return;

    const el = target.closest("a, button, [role='link'], [onclick], div, span");
    if (!(el instanceof HTMLElement)) return;

    const fingerprint = el.getAttribute(FINGERPRINT_ATTR) || makeFingerprint(el);
    const hadRuleOutline = el.classList.contains(RULE_CLASS);
    const hadLearnedOutline = el.classList.contains(LEARNED_CLASS);

    const modifiers = {
      ctrlKey: event.ctrlKey,
      metaKey: event.metaKey,
      shiftKey: event.shiftKey,
      button: event.button
    };

    if (isUserForcedNewTab(modifiers)) {
      return;
    }

    chrome.runtime.sendMessage({
      type: "NTLV_CLICKED",
      fingerprint,
      pageUrl: location.href,
      modifiers
    });

    window.setTimeout(() => {
      chrome.runtime.sendMessage({ type: "NTLV_CHECK_RESULT" }, async (response) => {
        if (!response) return;

        const openedNewTab = Boolean(response.openedNewTab);

        await updateLearning(fingerprint, {
          openedNewTab,
          hadRuleOutline,
          hadLearnedOutline
        });

        await scanAndApply();

        if (!hadRuleOutline) {
          if (!hadLearnedOutline && openedNewTab) {
            showToast("学習: 赤枠なし → 新規タブ を記録しました");
          } else if (hadLearnedOutline && !openedNewTab) {
            showToast("学習: 学習赤枠 → 同じタブ を記録しました");
          }
        }
      });
    }, 900);
  }, true);
}

function isUserForcedNewTab(modifiers) {
  return Boolean(
    modifiers.ctrlKey ||
    modifiers.metaKey ||
    modifiers.shiftKey ||
    modifiers.button === 1
  );
}

async function updateLearning(fingerprint, context) {
  const learning = await loadLearning();
  const entry = learning[fingerprint] || {
    score: 0,
    positiveCount: 0,
    negativeCount: 0,
    lastSeenAt: 0
  };

  if (context.hadRuleOutline) {
    entry.lastSeenAt = Date.now();
    learning[fingerprint] = entry;
    await saveLearning(learning);
    return;
  }

  if (!context.hadLearnedOutline && context.openedNewTab) {
    entry.score += 2;
    entry.positiveCount += 1;
  } else if (context.hadLearnedOutline && context.openedNewTab) {
    entry.score += 1;
    entry.positiveCount += 1;
  } else if (context.hadLearnedOutline && !context.openedNewTab) {
    entry.score -= 2;
    entry.negativeCount += 1;
  }

  entry.score = clamp(entry.score, -5, 10);
  entry.lastSeenAt = Date.now();

  if (entry.score <= 0 && entry.negativeCount >= 2) {
    delete learning[fingerprint];
  } else {
    learning[fingerprint] = entry;
  }

  await saveLearning(learning);
}

function clamp(value, min, max) {
  return Math.min(max, Math.max(min, value));
}

function makeFingerprint(el) {
  const host = location.hostname;
  const tag = el.tagName.toLowerCase();
  const role = (el.getAttribute("role") || "").toLowerCase();
  const target = (el.getAttribute("target") || "").toLowerCase();
  const href = normalizeHref(el instanceof HTMLAnchorElement ? el.getAttribute("href") || "" : "");
  const classes = normalizeClassList(el.className);
  const parentClasses = normalizeClassList(el.parentElement?.className || "");
  const hasOnclick = el.hasAttribute("onclick") ? "1" : "0";

  return [
    `h:${host}`,
    `t:${tag}`,
    `r:${role}`,
    `tg:${target}`,
    `oc:${hasOnclick}`,
    `c:${classes}`,
    `p:${parentClasses}`,
    `u:${href}`
  ].join("|");
}

function normalizeHref(href) {
  if (!href) return "";
  try {
    const url = new URL(href, location.href);
    return `${url.origin}${url.pathname}`;
  } catch {
    return href.split("?")[0].slice(0, 120);
  }
}

function normalizeClassList(value) {
  return String(value || "")
    .split(/\s+/)
    .filter(Boolean)
    .slice(0, 6)
    .map((item) => item.toLowerCase())
    .sort()
    .join(".");
}

function loadLearning() {
  return new Promise((resolve) => {
    chrome.storage.local.get([STORAGE_KEY], (result) => {
      resolve(result[STORAGE_KEY] || {});
    });
  });
}

function saveLearning(data) {
  return new Promise((resolve) => {
    chrome.storage.local.set({ [STORAGE_KEY]: data }, () => resolve());
  });
}

let toastTimer = null;

function showToast(text) {
  const old = document.querySelector(".ntlv-toast");
  if (old) old.remove();
  if (toastTimer) clearTimeout(toastTimer);

  const toast = document.createElement("div");
  toast.className = "ntlv-toast";
  toast.textContent = text;
  document.body.appendChild(toast);

  toastTimer = window.setTimeout(() => {
    toast.remove();
  }, 1600);
}